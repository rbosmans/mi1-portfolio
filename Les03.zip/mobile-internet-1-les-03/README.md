# Opdrachten voor Mobile & Internet 1, les 3 

In deze les gaan we voor het eerst een HTML pagina maken op basis van een screenshot mét design. Het is dan wat moeilijker om de juiste HTML elementen te herkennen, maar mocht je echt vastzitten, is ook een screenshot zonder design. De doelstellingen opgesomd:

- een structuurdocument kunnen bouwen aan de hand van een screenshot met opmaak
- de juiste volgorde van de elementen kunnen bepalen
- kunnen bepalen welke afbeeldingen wel en welke niet in het HTML structuurdocument moeten gecodeerd worden
- extra: Font Awesome iconen kunnen gebruiken

Begin bij **les03 opgave.pdf**


